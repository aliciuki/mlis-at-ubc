# 609C
## Twitter Rubbish

I made a Jupyter Notebook for our team's project, which analyzed Tweets about marine debris, ocean plastic, etc.
